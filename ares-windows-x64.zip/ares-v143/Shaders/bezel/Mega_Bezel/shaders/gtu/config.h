#pragma parameter GTU_EMPTY_LINE							" " 0 0 0.001 0.001
#pragma parameter GTU_TITLE		            "[ --- TV PROCESS GTU --- ]:" 0 0 0.01 0.01
#pragma parameter GTU_ON                    "          GTU ON" 0 0 1 1
#pragma parameter compositeConnection       "          Composite Connection Enable" 0.0 0.0 1.0 1.0

#define FIXNUM 6