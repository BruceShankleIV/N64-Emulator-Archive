
     MGlide 1.246H & MGSetup 0.22 alpha August 2000
     ----------------------------------------------

     MGSetup and MGlide are Copyright (C) 1997-2000 by Sebastien Chemin.
     All rights reserved.


   ***** READ THIS ******

   MGlide project is dead since september 1999. This version (1.246H) was
   started in june 1999 but never finished. But due to the popular demande
   I have decided to release it unfinished. So, there's a lot of bugs and
   the previous version is probably better in most case, but not in all
   cases. That's why you should try this version.

   SO, PLEASE, DON'T SEND ME E-MAIL TO ASK ME "WHY THIS GAME DOES NOT WORK WITH 
   MGLIDE" OR "WHEN THE NEXT VERSION WIIL BE RELEASED".

   MGLIDE IS DEAD !


   What's new:
     .use DirectX 7.0.
     .New optimized texture manager.
     .Real mipmaping (not auto-mipmaping).
     .MMX Optimized PixelPipeline (No 3DNow or SSE because I can't test them).
     .New Setup and Clipping Engine.
     .Better palette emulation (for TNT).

   **********************




           (PLEASE REVIEW THE ENTIRE CONTENTS OF THIS FILE!!!!)

  THE INFORMATION AND CODE IS PROVIDED AS IS WITHOUT WARRANTY OF ANY KIND,
  EITHER EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE IMPLIED 
  WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE. 
  IN NO EVENT SHALL WE BE LIABLE FOR ANY DAMAGES WHATSOEVER INCLUDING 
  DIRECT, INDIRECT, INCIDENTAL, CONSEQUENTIAL, LOSS OF BUSINESS PROFITS
  OR SPECIAL DAMAGES, EVEN IF WE HAVE BEEN ADVISED OF THE POSSIBILITY OF
  SUCH DAMAGES.
 
  **********************************************************************
  *  This program executable, help file and related text files may be  *
  *  used without fee by individuals for non-commercial home use, and  *
  *  by students, faculty and staff of academic institutions, with the *
  *  only condition of advise with mail to nanotech@uclub-internet.fr  *
  *  of his use.                                                       *
  *                                                                    *
  *  Non-commercial home use: Free, but please if you like MGSetup     *
  *                    send an e-mail to nanotech@club-internet.fr     *
  *                                                                    *
  *  All other uses: Contact Sebastien Chemin                          *
  *                                                                    *
  *                                                                    *
  *  Archive sites:  This program may be included on Government,       *
  *  academic and non-commercial Internet archive sites and on CD-ROM  *
  *  collections distributed by such sites, provided any charge is     *
  *  solely to recover the cost of distribution.  Any such             *
  *  distribution must contain the complete program, including this    *
  *  file.  Non-commercial Internet archive sites must not be in the   *
  *  business of making a profit from selling hardware, software,      *
  *  information or services.                                          *
  *                                                                    *
  *  For distribution rights and for all other uses, including all     *
  *  corporate use, please contact Sebastien Chemin                    *
  *  at nanotech@club-internet.fr for license information.             *
  *  I can be contacted via mail at <Sebastien Chemin ,190 Rue Notre   *
  *  Dame, 27130, Verneuil sur Avre, FRANCE>                           *                      *                                                                    *
  **********************************************************************

 DESCRIPTION:
 ============
 
   MGlide is a Glide to Direct3D wrapper. It allow to play lots glide games
   without a glide compatible card.

   MGSetup allows to configure MGlide.


 REQUIREMENTS:
 =============

   Software:
     . Windows 95/98.
     . DirectX 7.0
  
     ** MGSetup and MGlide have only been tested under Windows 98 **

   Hardware :
     . Processor Intel Pentium II, Pentium III, K6-2, K6-3, Athlon
     . 64 MB Ram
     . A Direct3D compatible graphic card with at least 4 MB RAM on board
       Nvidia Riva 128, 128 ZX, TNT, TNT2, Vanta, GeForce, etc...
       Intel 740
       3DLabs Permedia 2
       ATI Rage Pro, Rage 128, Radeon
       SIS 6326
       Matrox G200, G400, G400 MAX

 PAKING LIST
 ===========

 Files included in this package are:

    Readme.txt      This file.
    MGlide.dll      The wrapper.
    MGSetup.exe     The configuration program.


 INSTALLATION:
 =============

   YOU MUST HAVE PROPERLY INSTALL DIRECTX FOR THIS APPLICATION
   TO WORK. REFER TO DIRECTX DOCUMENTATION FOR THIS OPERATION!!
 
   1. If you can read this file, I beleive you have unzipped the package
      successfully.
         
   2. Copy MGlide.dll in your windows system directory and rename it to
      a more appropriate name (I think glide2x.dll is a good name).
   
   4. Launch the MGSetup program and chose your Direct3D driver and device.
      It's highly recommended to select an HAL device (see DirectX and/or
      your graphic card documentation if you don't know what is it).

   5. Push the "green" button to save your profile. You can obtain usefull
      informations on the choosen device in the right window just under the
      device list.


 KNOWN PROBLEMS
 ==============
 
   MGlide hasn't been tested on all graphic cards and with all DirectX
   versions. So MGlide may not work on your system (I need feedback).
   MGlide is know to work with just some glide applications. I need feedback
   to update the compatibility list.


 COMPATIBILITY LIST
 ==================

   Croc
   DethKarz
   Formula 1 97
   Grand Prix Legend
   MadTrax
   Mortal Kombat IV
   Myth
   NBA Live 98 & 99
   Need for speed 2 SE
   Newman Haas
   Pandemonium 1 & 2
   pod Gold
   Quake
   Quake 2
   Half-Life
   Sin
   Kingpin
   SpeedBuster
   Trickstyle
   The 5th Element
   Ultimate Race Pro
   Unreal
   Unreal Tournament
   And many others...

 WHERE TO GET IT
 ===============

   http://www.multimania.com/nanotech/


 SUPPORT
 =======
  
  There's no more support for MGlide. This project is definitly dead.


  Author
  ======

   Sebastien Chemin        e-mail : nanotech@club-internet.fr.
   190 Rue Notre Dame
   27130 Verneuil sur Avre
   FRANCE.
 