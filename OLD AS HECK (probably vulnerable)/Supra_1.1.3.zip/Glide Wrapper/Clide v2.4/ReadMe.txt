Clide R2.4 by ClideMan (ClideMan@hotmail.com)

Well, I finally got down to doing a new release..not too much new but I made some changes.  I have had some difficultly updating the wrapper due to numerous constrainst with time and resources.  I am sorry for the long delay.

*****I would like to draw your attention to the website www.alladvantage.com.  As I write this, they are upgrading their servers and they will soon be up again.  The website provides payment for you browsing the web.  You get paid $.50 an hour for each hour of browsing you do (for up to 40 hours).  Then your get additional payment of $.10 an hour for people who sign up and reference you as the person who told you about the site.  You alson get paid $.05 an hour for the people that they sign up.  The service guarantees privacy; they do not release email addresses or any personal information to anyone.  I think that all of you would be interested in free money.  This is the closest you get.  To get paid you must have a small banner window open.  This window will be the key to free money.

I would like you all to join and reference me as the person who told you about the site.  That way I get paid for all the work I did.  So please if you use Clide, like Clide or just want to make free money, join all advantage.  I can update the wrapper more if enough people register and browse with the little paying window.

My reference number is ARV-574.  Please register it is good for everyone.

Thanks,
ClideMan

Added multipass color effect support to allow all cards to be able to handle effects such as adding.
Fixed annoying blink bar
Added nice fps counter
updated setup tool
added measures to allow regular loads/save once before the program crashes


