**************************************************
	   OpenGLide version 0.05
	By Fabio "Glorfindel" Barros
**************************************************


	OpenGlide is a Glide->OpenGL wrapper. 

Ok, but what is a wrapper? 
	A Glide Wrapper is a program that fools the applications and games that there is a Voodoo board in your computer, so you can run those Glide games in any 3D accelerator that supports OpenGL. 

What is OpenGL?
	OpenGL stands for Open Graphics Library, it is a "Graphics library" ;-) that allows the programmer to do 2D/3D applications and games, it is a standard in these days and almost all Operational Systems have it. But, this version of OpenGLide only runs on Windows systems ( 95/98/NT/2000 ).

Installation:

	Copy or Unzip the Glide2x.dll file to the "windows\system" directory ( usually: c:\windows\system )
	And copy the OpenGLide.exe file to any directory and run it, then you can play (or try to) a Glide game.
	

Configuration File
------------------

	Now There is a configurator file for OpenGLide made by Daniel Bauman, it is great and let you great different configurations for different applications/games, so use it.

	There is a OpenGLid.INI file on the windows directory, this file is the configuration for OpenGLide , and you edit it, but i suggest using the configurator included.


*	PalettePrecision=16

	This value can be beetween 1 and 255. Raise it to get more speed in Palette based games, but you 	will loose visual quality.

*	TextureMemorySize=8

	This is the ammount of Megabytes the wrapper is using to store Textures, the Default value is 8 	Megabytes, i didn't make much test about it, so i cannot say that raising it will be better or 	worse, so i expect as much feedback as i can in this Option, Test it for me and tell me which value 	is best for your system.

*	WrapperPriority=0

	The Priority is a number beetween 0 and 5, where 0 is greater priority and 5 the lower.


Obs.	All the other configurations can be 0 (zero, disabled) or 1 (one, enabled), the default config file is fine.

*	EnableMMX=1

	Enable MMX extensions to processors that support it.	

*	CreateWindow=1

	This is a hack that solves some bugs, like the flicking in UltraHLE, it is not fully tested, so if something goes wrong, try disabling it.

*	InitFullScreen=0

	Not working ok yet, but will soon in the new patch.

*	EnableMipMaps=1

	Enable auto mipmap feature of OpenGL, it is mutualy exclusive with EnableWrap565 or 	EnablePackedPixelsEXT.

*	EnableFog=1

	Enables the fog support, actualy it will only works if the EnableFogCoordEXT is enabled and your 	video board supports this extension (NVidia as far as i know), but fog will ba emulated soon for 	other video boards.


*	EnablePrecisionFix=1

	This is another hack for Glide applications that uses w-buffer, as OpenGL does not support 	w-buffer, we have to do some math to emulate it, if the z-buffer is over 16bits then we do not need 	this. (this is the cause of the sometimes missing triangles that appears in Mario64, Zelda...)

*	EnableWrap565=0

	This converts the 565 texture mode to 5551 mode, sometimes it is fast sometimes not, so leave it 	disabled.

*	EnablePackedPixelsEXT=0

	Enables some texture extensions for OpenGL, same as above.

*	EnableVertexArrayEXT=1

	Enables the Vertex Array, fast, leave it enabled.

*	EnableSecondaryColorEXT=1

	Enable a great support for Glide, if the OpenGL support this extensions (NVidia again) the graphics 	becomes much better.

*	EnableFogCoordEXT=1

	Support for Fog Coord is the key to Fog applications, by now.


ThroubleShooting
----------------

	If something goes wrong in the graphic section, try disabling these options:

	EnableWrap565=0
	EnablePackedPixelsEXT=0
	EnableVertexArrayEXT=0
	CreateWindow=0


Details
-------

	If you enable VertexArrayEXT and everything is fine, leave it enabled, because it is faster.

	Fog only work if FogCoordEXT is enabled and your video board support this OpenGL extension, all TNT/TNT2/GeForce with drivers 3.x have, i don't know about the rest. But i plan on doing fog for others boards too, but will take long.

	regards with trying to run this wrapper in UT:
	* when you start UT it doesn't show the window or the window is blank, 
	 just hit ALT-TAB to another window and then hit ALT-TAB again to UT
	 window, this should work.

	* If everybody helps, support will be great *


Thanks
------
	I would like to thanks all of you who supported me and sended Log files, configurations files, error files, bugs, suggestions, questions, without your help, i would have quit doing this a long time ago, but i would like to  really, really thanks the guys that tested and tested and tested my Beta versions and helped me, giving me space on webpages and support:

	All the staff of GU ( www.glideunderground.com )
		* Khalid
		* GrdLock
	Tuomas Lukinmaa
	Le Routier
	Derek Smart
	Luigi from Emulation64
	John L. Dahlstrom
	Tim Macsay
	Aussie
	Keith Duthie
	Daniel Bauman


Please, continue to send me BUGS and solutions

Please e-mail me at:

openglide@usa.net

So i can work hard to make it a "partial" (never will be fully) 
Glide->OpenGL wrapper.


Version 0.05
------------

	MMX code, lots of code optimizations, greater fog support, priority selecting, some bugs tracked.


version 0.04a
-------------
	Some bug fixes and the ability to change the ammount of Texture Memory

version 0.04
------------
	Lots of OpenGL extensions implemented
	Faster
	Fog implemented if you have FogCoordEXT
	Some minor bugs fixed
	Should work on more games


version 0.03beta
----------------
	Palette textures work, at last....
	UT runs "almost" perfect, it still has that ALT-TAB bug in the begining

version 0.03alpha
-----------------

	Palette textures should work, but it is buggy somehow, removed 
directX because it didn't do anything, fog doesn't work, but will soon.
	Faster than previous versions.
	Lots of bugs, this is because i am redoing most of the code as i
restarted to work on the wrapper.


version 0.02
------------

	I know i should not do this but this release fixes a lot
of blend modes and adds some other things like Fog. I started to work 
to mix DirectX and OpenGL to make LFB accesses, but it doesn't appear
to be working now.
	Fog is a little bit slow, since it is emulated, so i put an
Option in the INI file if you want to enable it. Well it is a little
buggy too... ;-)
	DirectX is enabled in the INI too, but it doesn't do much, try
it out and send me the Results.
	There is another option in the INI that fixes w-buffering 
problemsin 16-bit z-buffer boards, i did this way because the original 
version works better in 32-bit color (24-bit z-buffer).

Versions prior to 0.02
----------------------

	Well, not much to say here.
	This wrapper has only been tested on UltraHLE,
don't claim it does not work with anything else.
	This is not finished, not perfect, or anything else,
it is just another wrapper. It runs Zelda with menus, and Mario
with all that transparent stuff.
	It has bugs, lots of them, Mario's black face is one of them,
the Nintendo Logo at zelda is another, i am fixing it.
	If you wanna run Mario without artifacts, set your desktop
to 32-bit color (only the cards that accept it: TNT, Riva 128...).
	I don't know how this wrapper will behave on other systems, 
mine is a TNT with a k6-2 400, so enjoy... or not.... ;-)
	When you run it for the first time it will create an INI file,
"OpenGLid.INI", the only option that exists is "InitFullScreen", you
can set it to 1 (one) ot 0 (zero), this means, if it is 1 than it will
change resolutions and init fullscreen. If a game, or a demo does not 
work ok at fullscreen, change it to 0.
	I forgot, if you hit ESC on ultraHLE and nothing happens, 
try ALT-TAB until you see UltraHLE program, and then hit ESC, 
this will soon be fixed.

	regards,

Fabio Barros
openglide@usa.net



VERSIONS
========

Version 0.01a
* Faster, > 20% on my system
* INI file to choose beetween Fullscreen and Window mode

Version 0.01b
* Faster, 10% over 0.01a
* Fixed (i hope) the memory hungry of OpenGLide

Version 0.01c
* Fixed the Texture bug
* Some more optimizations

Version 0.02
* Fixed a lot of Blend modes, so Mario's black face is gone, N64 logo on Zelda looks ok
* Add Fog emulation
* Started DirectX integration
* 16-Bit w-buffer fix

Version 0.02a
* Fixed more Blend modes

Version 0.02b
* Some other fixes

Version 0.03alpha
* Lots of bug fixes
* Palette textures work, but there is a problem with blending with Palette, humm, any help?
* Removed DirectX integration (didn't work)
* Removed Fog, was too buggy, i will start again