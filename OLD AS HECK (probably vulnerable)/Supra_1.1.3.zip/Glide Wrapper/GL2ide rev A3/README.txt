--- Revision 3 README
Nothing very relevant in this release except that I have fixed the fullscreen/window bug and some glitches that didn't exist in the original GL2IDE but have appeared in Rev A2. I personally didn't find that annoying but apparently some people did and I think I will stop making new revisions unless I have new ideas on how to make this wrapper faster,

--- Revision 2 README
I have attempted to make Zelda run faster in my machine by optimizing the glide wrapper. I didn't succeed and the sound skipping problem still exists and very noticeable. This is due to my lack of knowledge in OpenGL and Glide. Anyway, I've decided to re-release this stuff because I have made many changes to the source code. Apparently, there is already another version B by Greg around. He hasn't released the source code (yet) so I don't know what he has done to have accelerated his glide wrapper but one thing I have noticed that it no longer runs in WinNT but only in Win98. But anybody can feel free to look at the changes I have done. It MIGHT be useful :). I don't have any glide games besides UltraHLE, so I may have broken a lot of things that were well-behaving in the original GL2IDE. I think I am at my wit's end in getting this wrapper running faster.

Technical note: in the last version, I didn't expect anybody to recompile it under BCB3 again so I didn't include the .bpr file. But this time I have included it. Also, anybody trying to get the thing recompiled in VC++ should get the original GL2IDE first to get the workspace and other options enabled. The file names are identical and I didn't add any new file except the main project GL2IDE.CPP, but this is used exclusively in Borland C++ Builder so you can just ignore it. I claimed that BCB3 is very poor in optimization (even though I've turned one all the optimiations) and it is true: it couldn't even optimize loops like: for (int i=0; i<x*y; i++) where x*y is constant inside the loop. It attempts to multiply x*y everytime. So I believe that recompiling the wrapper in VC++ can make it faster.

One further note: if you want to recompile, you must have the Glide SDK installed. Besides that, make sure that your OPENGL header files are current. This is not a problem for users of VC++ but a big headache for BCB3 owners.

--- Revision 1 README
This is a small revised version of M&M GL2IDE. I didn't make anything major since I know virtually nothing about OpenGL nor Glide nor DirectX. I just wanted to have the text displayed properly in Zelda64 and I succeeded partially. Anyway, feel free to try it, but I don't think I am able to correct things that are displayed incorrectly nor I can put more time on this stuff. I mean, this is the end of the my development on this wrapper.

I have tested this DLL exclusively with UltraHLE in WinNT (but it should also work in Win95/98) and I am using a Creative Riva TNT card with the detonator driver. I have also gone a little bit off the mainstream as I used Borland C++ Builder 3 instead of Microsoft VC++. I urge anybody interested in continuing this wrapper to use back either Watcom C++ or VC++ since BCB 3 didn't optimize very well the code. I have mainly changed the Render and ConfigSpecialEffect part. The rest should be the same as GL2IDE. 

Just rename gl2ide.dll to glide2x.dll to try it. I hope I have accelerated the wrapper by more or less 1% but I am not really sure.
Since the functionality is the same, download GL2IDE first, test it and only then use my revised version if the previous version works.

Francisco
---
frleong@hotmail.com
