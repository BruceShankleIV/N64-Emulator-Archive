 Sorry this couldn't be released earlyer but i've been kind'a busy with something else
lattely. Please do not forget to change the setting in the xglide.ini file if your planning
on running the wrapper with UltraHLE on a non-w-buffer card. Turn on UltraHLE compatibility
mode!

Helder Filipe Cunha da Silva
xglide@technologist.com