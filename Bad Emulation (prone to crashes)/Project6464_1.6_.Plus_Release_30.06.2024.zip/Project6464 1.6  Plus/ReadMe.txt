================================================
          Project64 Plus, by Zilmar, Jabo , Witten & Gent
		  Copyright (c) 1998 - 2024
		  Contributors:	 Azimer, Icepir8, RadeonUser, Hacktarux, Nekokabu
================================================

Project64 1.6  Plus - For Windows XP and above (30th June 2024)

What is this about?

Project64 1.6 Plus is a free and source-available emulator for the Nintendo 64 and It is written in C/C++ currently only for Windows.
The project is a feature & vulnerability update fix of the original Project 64 1.6 source.
It is targeted at the communities that still desire to use 1.6's ability to play Rom Hacks and a-like because of an incorrect core
that lets a lot of things slide when it comes to compatibility. 

This is not intended for development use or is it a modernised 1.6 core, it is just a "Safety Fix"
For its loyal users and some added features that they may enjoy.

================================================

## Changes

- Arbitrary code vulnerability fix.

    TLB miss in write opcodes are now generating exceptions as expected. This solves a vulnerability that can allow roms
    to run arbitrary code in previous releases.  
	
- TLB: extra checks for overflow buffer mapping for user TLB entries

	Adds an extra check for user mapping TLB further than allowed buffer size.

- Retain 1.6 original ROM Hack compatibility

- Advance Mode enabled by default (allowing ) [to name a few]

  - File/Rom Information
  - System/Screenshot Capture
  - Options/Configure RSP Plugin
  - Help/About INIFiles 

- Save/load states (10 extra than original release)
- Game Information in File & Rom Browser (Popup Menu)
- Good Name replaced by Game Name in RDB & Browser Tab.
- Internal Name replaced by File Name in Title Bar when emulating.
- New Entry uses File name not Internal Name to add to Game Name in RDB
- Rom Browser uses File name to display a game not currently in RDB with the status of unknown,
  but once added to the RDB it will use the Game Name= instead.
- Always remember cheats as default so user don't have to re-enable after every close
- Max 10 Recent Roms as default
- Max 10 Recent Rom Dir as default
- Rom Dir Recursion as default, this allows sub-directories to be included in rom browser
- Jabo specific pemrcheats read from the jabo.ini so they do not effect other plugins as no longer enabled in the rdb.
- Display build date and time in About dialog title bar for easy build version recognition
- Uninstall registry settings and delete Project64,cache from Help/Uninstall Application Settings
- Uninstall Jabo registry settings from Help/Uninstall Jabo Plugin Settings
- Added AziAudio_Legacy.dll as default Audio plungin
- Added NRage_Legacy_Input.dll as default input plgin
- Added Legecy No Audio plugin

================================================

Greets and Thanks:

Once again we would like to give a Big Thanks to all who assisted in the journey of Project64 1.6 Plus on Discord,
and a special thanks to Fanatic 64, Derek "Turtle" Roe, Bruce Shankle IV & aglab2 for their support and tireless
testing/checking to help make this available for everyone.

This was a true trip down memory lane for us mixed with Old and New Dev Teams combined!

Much respect and good wishes to all in the MiB64 Dev Discord Server.

================================================