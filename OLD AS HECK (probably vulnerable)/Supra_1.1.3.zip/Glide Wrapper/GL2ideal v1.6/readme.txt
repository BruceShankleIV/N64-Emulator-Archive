GL2Ideal	Glide2 -> OpenGL Wrapper


	This wrapper is based on the source code of 'GL2IDE rev. A'. 
	And I make a change for image quality.
	If you think this has a problem(copyright or coding). Please send a E-mail to me.

	I have tested this wrapper with UltraHLE on RivaTNT(Windows 95/98/NT4/2000) only.
	So others may not work.


Usage:
	Unzip Glide2x.dll into System directory (usually c:\windows\system or
	c:\winnt\system32) or same directory as target application.


Known Problems:
	- When running UltraHLE on Windows NT/2000. Sometimes it fails to open the window.
	  In a case like that, I hit F5-key 2-3 times continuously. It seems work fine.
	- Screenshot has a problem in Window-Mode.


History:
	version 1.6		Jun 30 2001
	 +	AlphaCombine bug fix
	 +	ColorClamp fix (special game fix)
	 +	Screenshot bug fix (in Custom Resolution Mode)

	version 1.5		Jun 24 2001
	 +	Fog Emulation
	 +	Configuration Tool
	 +	GL_ARB_texture_env_combine support

	version 1.4		Jun 30 2000
	 +	DepthMask bug fix
	 +	Minor optimizations
	 +	GL_ARB_texture_env_add support

	version 1.3		Mar 19 2000
	 +	Minor bug fix ( grDrawLine(), grDrawPoint() )
	 +	Minor code optimizations
	 +	PentiumII-only instructions were removed. Now available on Pentium and K6.
	 +	Color clamp method was changed to simpler and faster way.
		  This may causes problems in some games. (Black background goes blue.)
	 +	GL_NV_texture_env_combine4 was implemented.

	version 1.2		Mar 4 2000
	 +	Some minor bug fix
	 +	More code optimizations

	version 1.1		Feb 26 2000
	 +	Some bug fix
	 +	Lots of code optimizations
	 +	GL_EXT_texture_env_combine was implemented.
	 +	Color clamp method was changed. (Pinky-background bug was fixed.)

	version 1.0		Feb 14 2000		First Release
	 +	Many bug fix
	 +	grLfbReadRegion() was implemented. Screenshots now work.
	 +	GL_EXT_texture_env_add was implemented.



Mamoru Shiroki
	E-mail:		msiro@geocities.co.jp
	Home Page:	http://www.geocities.co.jp/SiliconValley/8346/gl2ideal/
