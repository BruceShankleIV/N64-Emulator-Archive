Rename this folder to Lang if you wish yo use languages.

The English, English_alternative and Swedish .pj.Lang files have been updated for Project64 1.6 Plus,
the others are a wee bit outdated, so if you would like to update any language please feel free to do so.
Just use the new updated English.pj.Lang as your template to add any new items added since 1.6.

If you wish to add or update a language file for the project, you can do so by submitting it via the GitHub Pull Request.