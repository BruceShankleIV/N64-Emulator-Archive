********************
GL2IDE
********************

This wrapper is based on the source for Let's GLiD3D v0.24.
It was ported to use OpenGL by M & M

It should work fine on any OpenGL compatible card (or even in software, but believe us,
you don't want to run this in software)

Since this wrapper is strictly developed to support the UltraHLE emulator, we
don't suspect it will work with many other applications (there's too few glide settings
implemented).
But for running UltraHLE, it works just fine. 

Configuration of the wrapper is done with the included GL�IDEConfig


Settings:
-----------

Run Fullscreen         - When this box is checked, the wrapper tries to switch to fullscreen mode
                         if it fails, or if the box is unchecked, it will run in a window.

Blend Fix              - When this box is checked, we do a little trick to prevent the loss of polygons 
                         (i.e. the kneecaps on the horse in the Zelda intro).
                         But since this is not done in the "correct" fashion, we don't recommend setting it
                         if you're running anything else than UltraHLE

Goldeneye Fix	       - Activating this will make the textures in the Goldeneye 007 rom not be transparent.
			 A side effect of this setting is some strange and perhaps unsettling 
			 non-fades in other games. I recommend not setting this when playing anything but
			 Goldeneye.

Auto Generate Mipmaps  - Activating this Will automatically generate several mipmap levels of each texture,
                         will most times give a better visual experience in UltraHLE, but is not guarateed to
                         work flawlessly

Use ZInverse for depth - This should be active on TNT cards, otherwise you'll get som pretty ugly results from
                         time to time. On other cards we don't know which to recommend. 

Fog Mode               - Recommend this be turned off. It has many bugs.

Show FPS	       - This will enable a small Frames per Second counter in the upper left hand side of
			 the screen. I use it for speed optimizations. You can use it just for kicks.			


Recommended settings:
----------------------

The most failsafe mode would be to leave everything off except for "Use Z inverse for depth" and possibly
"Run Fullscreen".
When running UltraHLE, we recomend also checking Blend Fix. If you feel adventureous, feel free to experiment
whith the other settings, the worst thing that can happen is that you get a screen full of fog (will occur
if you have "Z inverse for Depth" & "Fog Mode 1").

When running on a TNT based card, we currenty recomend using the Nvidia 0.48 drivers if you want to enable fog
(for some reason, fog seems to work differently in the Detonator drivers).

Known Problems:
-----------------

 When running UltraHLE:
  WaveRacer - Black background (FIXED in 2B)
  GoldenEye - Everything is transparent, giving a rather interesting look =)  (FIXED in C)

 When running other stuff:
  Most likely a whole bunch of problems, nothing else we've tried have worked.

Credits:
---------

Original Code: M & M
Rev A: Francisco
Rev B,C: Greg Love
GUI design: M
Original GliD3D code by: Let

Have fun! And remeber, it's GL<SQUARE>IDE!!

Revision History:
GLID3D:	
	Initial Release (with source code)
	Release by Let Software
	* This started the whole phenomena
	* Based on using Direct 3D to emulate Glide Calls
GL2ide: 
	Release by M & M (GL2IDE@HOTMAIL.COM)
	* First translation to using OpenGL code
	* Very solid performer
GL2ideA:
	Release by Francisco (frleong@hotmail.com) (with source code)
	* Fixed the zelda text bug
	* Made some performance increases.
GL2ideB:
	Release by Greg Love(lichbait@earthlink.net) (without source code)
	* BAD VERSION: ASKED FOR ALL SORTS OF DLL'S USERS WOULDN'T HAVE
GL2ideB2: 
	Release by Greg Love(lichbait@earthlink.net) (without source code)
	* Fixed the Dll problems.
	* Not based on Francisco release (I couldn't get his source to work, I think I'm missing a header file)
	* Fixed the zelda text bug
	* Small performance increases.
	* All keys should function in game now, full screen and in a window.
GL2ideA2:
	Release by Francisco (frleiong@hotmail.com) (with source code)
	* Update to use C++ objects 
	* Unsure of feature and performance increases
GL2ideC:
	Release by Greg Love (lichbait@earthlink.net) (without source code)
	* Some performance increases
	* Added option for Frames per second counter
	* Fixed Goldeneye Transparency problem
	* Stopped flickering of error messages and system data from Ultra
        
                 
                  



