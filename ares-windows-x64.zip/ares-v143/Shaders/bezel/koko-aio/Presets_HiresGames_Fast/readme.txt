These presets match the upper folder presets, but without internal upscaling.
This lowers GPU load and maintains similar quality,
assuming the game's native resolution is sufficient.