================================================================================

                    UltraHLE - Ultra64 High Level Emulator
                  Copyright (c) Epsilon and RealityMan, 1998

================================================================================

Overview
--------

Epsilon and RealityMan are very proud to introduce you to what we think may well
be the emulation release of 1999, UltraHLE.  UltraHLE is a Nintendo 64 Emulator
for Win95/98 and WinNT based PC systems.  Taking full advantage of Pentium 
processors and 3DFX (Glide) graphics cards this emulator allows you to play some
of the biggest releases to date that the Nintendo 64 has had.  Games such as
Zelda: Ocarina of Time and Super Mario 64 run superbly on PII 300Mhz systems. 
But don't be put off by the system requirements, PII 2xxMhz systems can runs 
this emulator just as well with Voodoo1 based technology as well as Voodoo 
Banshee.

System Requirements
-------------------

We cannot test UltraHLE on all combinations of system, although we do have 
several, so we cannot guarantee that UltraHLE will work on all systems.  To 
give you an idea of what can run UltraHLE we have the following 3 requirements.

a)	MINIMUM REQUIREMENT

	PII 233Mhz Processor
	32MB System RAM
	Voodoo1 Based 3DFX Card (Glide Drivers Required)

b)	RECOMMENDED REQUIREMENT

	PII 300Mhz Processor
	64MB System RAM
	Voodoo2/Banshee Based 3DFX Card (Glide Drivers Required)

c)	IDEAL REQUIREMENT

	PII 400Mhz Processor
	64MB System RAM
	Voodoo2/Banshee Based 3DFX Card (Glide Drivers Required)

Running The Emulator
--------------------

                       !!! PLEASE READ CAREFULLY !!!

       In order to use UltraHLE with commercial rom images, you MUST have 
 purchased and own the original rom cartridge.  If you use rom images that are
              illegally in your posession you are in violation of 
                    United States and International laws.

   THE AUTHORS OF ULTRAHLE DO NOT CONDONE THE USE OF ILLEGALLY OBTAINED ROMS


Using UltraHLE is a fairly simple process but please read these instructions
carefully before using the emulator.

Once you have unzipped the downloaded UltraHLE distribution into a directory
of your choosing you will notice 3 files.  This README file plus ULTRA.EXE 
and ULTRA.INI.

Before starting UltraHLE we recommend that you edit ultra.ini, with the text
editor of your choice, to set the default rom directory.  This setting is in 
the [default] section of ultra.ini and the parameter you will need to change 
is rompath=xxx. For example, if you have your rom images store in h:\roms
then this parameter will need to read;

	rompath=h:\roms

You can also adjust savepath, which tells where you want to store the emulator
save files, and set the starting resolution. These are just defaults and can
be changed when the emulator is running. There are also a lot of other settings
that tell the emulator how to deal with some particular games. It's best to
leave these untouched.

Right, now you can start UltraHLE (ultra.exe).

Once the emulator has started you will notice the GUI is broken down into four
main parts.

a) The Menu Bar       Where you can access the functionality of UltraHLE.
b) The ROM List       This is where any roms the emulator finds in the directory
                      that you specified when modifying the 'rompath' setting 
                      are displayed.
c) The Debug Window   UltraHLE does not yet run ALL available games so error
                      and warning notifications will be displayed here.
d) The Status Bar     This will display general statistics about a rom whilst
                      it is executing.

The Menu Bar has five main menus which allow you to do the following:

+ File|Open (Ctrl+O)

Using this calls the standard windows file open dialog window.  From here you 
can select a rom image that may not be located in your preferred rom directory.

+ File|Load State (Shift+F9)

Once a rom has been loaded you can load a previsouly saved state file. Put 
simply, this allows you to save game states so that you can come back and play
on from where you left off.

+ File|Save State (Shift+F6)

This option allows you to save a game state file with a name of your choosing.
The state takes about 2-4MB of disk space depending on how much memory is in
use. 

+ File|Quickload 'ultra.save' (F9)

Ultra.sav is the default save state filename.  This option and Quicksave allows
you to load and save state files without flipping out of a game.

+ File|Quicksave 'ultra.save' (F6)  

See Quickload. In addition to saving the current state as Ultra.sav, a backup
of the previous Ultra.sav is renamed Ultrabak.sav. See 'Known Problems'.

+ File|Exit  

Allows you to shutdown the emulator.

+ Emulation|Start (F5) 

Start a rom executing. The 3DFX becomes active when the game starts to draw
graphics. You can return to the user interface by stopping emulation using
ESC.

+ Emulation|Stop (Esc)  

Stop a rom executing. This also closes the 3DFX so you can see your desktop.

+ Emulation|Pause (F7)

Pauses execution. The difference to stopping is that the 3DFX remains active,
so you can see the graphics. Useful for screenshots. Press again to continue.

+ Emulation|Reset 

Restart rom execution.

+ Emulation|Unlock 

If the game becomes stuck, this option might help. See 'Known Problems'.

+ Options|Sound Emulation 

Allows you to Enable/Disable Sound. Sound does take a notable amount of 
processing time, so disabling it will make a game run faster. Also useful
if the game has sound problems.

+ Options|Graphics Emulation 

Allows you to Enable/Disable Graphics. This is mainly useful if you want
to hear the sound properly with a slower computer. If the computer is not 
fast enough in most games the sound is the first thing that starts to have 
gaps (when the sound data is not calculated fast enough). 

+ Options|Screen Resolution 

Allows you to change the default resolution.

+ Options|Wireframe (Ctrl+W) 

Turns Wireframe Mode on and off. This is mainly a debugging feature, but
it can also be used to see the world if there are graphics bugs that make
it black or otherwise unvisible.

+ Options|Screenshot (F10)

At any point during a game you can take a screenshot of the current frame.  
Pressing F10 creates graphics files in 'targa' format in the current directory.
These files are incrementally named, e.g. 01.tga, 02.tga etc.  
Please Note: You cannot take a screenshot when the emulator is stopped.


+ Controllers|Configure

Currently, UltraHLE only supports one controller. Selecting this option allows
you to see the predefined keys for the emulated controller keypad. The only
option that you may configure currently is whether you wish to have the analogue
joystick emulated on the keyboard or using a joystick. The other controllers
and configurability will be added later.

The current Controller 1 setup is as follows:

Start		S
A Button	A
B Button	X
Trigger		Z	(Underside of Controller)
Left 		C	(On Front Left of Controller)
Right		V	(On Front Right of Controller)
C-PAD (Up)	I	(the keys are arranged to a similar T-formation
C-PAD (Down)	K	 as the normal arrow keys)
C-PAD (Left)	J
C-PAD (Right)	L
D-PAD (Up)	T	(the keys are arranged to a similar T-formation
D-PAD (Down)	G	 as the normal arrow keys)
D-PAD (Left)	F
D-PAD (Right)	H
Stick (Up)	Up Arrow
Stick (Down)	Down Arrow
Stick (Left)	Left Arrow
Stick (Right)	Right Arrow

Shift Key - When used in conjunction with a Stick movement the movement is slower.
		In most games holding shift means walking instead of running.
Ctrl Key  - When used in conjunction with a Stick movement the movement is even
            slower than with the Shift Key. This makes mario tiptoe.

Enough Already, I Want to Play a Game
-------------------------------------

OK, there are two ways to start a rom executing.  The easiest method is to select
a rom, from the Rom List, by double clicking the rom name.  The rom will auto-
matically load and start executing.  The other way is to use the File|Open menu
option which will allow you to browse you system for any rom images.  Select a
rom image and then click Open.  Again, the rom will automatically load and
begin executing.

Known Problems
--------------

We have tried to concentrate on the "best" N64 games first. The two most tested
games are Mario and Zelda, which have been played very far using the emulator.
We are most interested in hearing about your problems, if they happen in Mario 
or Zelda. We do about a number of minor graphics bugs, so please only report
about either major graphics or sound glitches, or crashes.

Other games marked playable in the compatibility list (on our website) have
been tested only briefly, so new problems might surface when you play them
further. In addition there are many games that start up, but crash at some
point. This is simply because the emulator does not try to emulate everything,
only the minimum set of features required for our target games to run.
Emulated features are added one at a time.

One known problem is with save games (save/load state). The emulator generates
a lot of special structures in the process of emulation to speed things up.
These take several megabytes and are not saved due to their size. Instead, they
are cleared when you save the state, and regenerated when execution continues.
However, in some cases the game gets stuck or corrupted in the save process.

If the game stops running (usually graphics stop, sound might continue), there
are two things you can try:
1) stop emulation, and select Emulation | Unlock. It does some "magic" stuff
   that sometimes gets the problem fixed
2) try restarting the whole emulator and then loading the savegame. Sometimes
   an emulation bug corrupts the emulator itself, and then this helps.

If these don't work, that savegame is lost. So use at least a few savegames and
save to them alternatively, so you won't lose everything in case of problems.
If you use the QuickSave/Load features, they do this for you. The state is
saved to Ultra.sav, and the previous Ultra.sav is renamed to Ultrabak.sav. So
if you notice that Ultra.sav got corrupted, you should still have the previous
savegame left.

You can load a new game without exiting the emulator. In some cases this can
lead to problems though, if the previous game left the emulator in some
undefined state (most often happens if the previous game crashed). In this
case restarting the emulator helps.

There are also some differences between 3DFX-cards. On Voodoo1 some graphics
modes are not correct (Mario works pretty ok). On Banshee dual texture is
not supported, and some complex transparent textures are rendered in a
simplified way (like flames in Zelda). On Voodoo2 (which is our main test
card) all features should work.

If windows starts beeping when you play, you have  probably accidentally 
selected the listview or the status window in the user interface with mouse.
Press ESC and F5 to temporarily stop emulation.

Contacting Us
--------------

Before you fire up your mail program and send me mail, keep these in mind:

   - Don't email if you're looking for ROMs.
   - Don't email and ask when game 'x' will work.
   - Don't email when the next release will be out.
   - Don't email and ask if your system will work.

If you proceed to email us for any of these reasons (or anything that can be
explained on my webpage) you won't get a reply.

If you still want to email us, send mail to: ultrahle@emuunlim.com

================================================================================

   All references to Nintendo, Nintendo 64, or N64 are copyright Nintendo of
                   America, Inc. and Nintendo of Japan, Inc.

    Nintendo 64, N64, and the Nintendo 64 logo are registered trademarks of
              Nintendo of America, Inc. and Nintendo of Japan, Inc.

                 Nintendo is in no way affiliated with UltraHLE.

================================================================================

