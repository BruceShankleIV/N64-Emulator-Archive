MUGlide

Mario64-ultrahle-glide-wrapper:

this is a glide wrapper that works with ultrahle
it plays mario perfictly on my g200, with text and trees :-)
*zelda's title comes up great and looks great except no scroling diloge text(and entering name)
this might be just a g200 problem but it works better than xglide Plus its not white
treat it just like xglide (go to glide under ground for the how to make xglide work)

it should be named right for you so all you have to do is put it in your ultrahle dir

it makes a log file but dont be alarmed it dosn't grow like xglide's


*also you need to set your desktop and ultrahle to 640x480 in order for it to work maximumised

*if you swith windows while playing (including going to ultrhle) it will not come back right

if you people can find away to fix the *'s tell me and the rest of the people at glide undergroud webpage/forms


e-mail me any time at matadoor5@usa.net
do not ask me for roms!!!! but please give me tips and help me and the rest of glide-wrappers

