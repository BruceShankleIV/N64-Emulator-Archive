XGl200 0.04a a.k.a. Scott's Glide Wrapper
------------------
In case you don't know, this is a program that emulates 3dfx
hardware by translating Glide (3dfx's proprietary programming
interface) calls into Direct3D calls.
I'm developing this on a system with a G200, so results are 
probably best on that card.  However, I have heard that this
wrapper works well on ATI Rage Pro, Rage 128, and TNT cards
as well.


Usage (Be sure to read this!)
------------------
Just copy the file glide2x.dll to somewhere in your path. 
Alternatively, copy the file to the game directory (e.g., 
the same directory as ultra.exe in the case of UltraHLE).
You must also copy the configurator.exe file to somewhere.
The location is not critical, but you MUST run it before 
using the wrapper, and you must rerun it for every new 
version of the wrapper.


Testing
------------------
I have only tested this on my home system:
PII-400
G200
DirectX 6.0
Win98

Games:
Perfect:
None :-)

Almost perfect:
MadTrax
Croc - Legend of the Gobbos
Need for Speed 2
Outlaws
UltraHLE /w Mario 64
UltraHLE /w Quake 64
UltraHLE /w Zelda 64
UltraHLE /w Bomberman Hero

Very playable:
UltraHLE /w Doom 64 (very dark)
UltraHLE /w StarFox
UltraHLE /w WaveRace
UltraHLE /w Banjo Kazooie
UltraHLE /w Tetris 64


Playable, but a little slow:
UltraHLE /w Goldeneye
UltraHLE /w Mario Kart
UltraHLE /w Rampage World Tour

Playable, but ugly:
NBA Live 98
Pandemonium 2
Unreal



These are the only games I have to try it with, but let me know
if you have different results!


Source code
---------------------
Licensed under the Library GNU license agreement.  See below for details.
If you want to help develop, I'm not really interested in a partner,
but if you fix a nasty bug, let me know and I'll be sure to
include it.
You need VC++ 6.0 to compile the source.  No need for the  Glide 2.0 SDK 
anymore.


Credits
---------------------
Massive credits go to Khalid Shaikh of the DirectGlide wrapper and
Let of the Glid3D wrapper.  A number of times I got past sticky points
by glancing at (or sometimes cut & pasting from :-) these guy's code.
Other credits go to (for spotting bugs and other stuff):
Francisco Leong    For some great performance tips
Mark Bridgett	   For the awesome XGl200 logo!
Norman Jonas	   For some great programming tips
"ClideMan"	   For the great idea of using execute buffers
Wes Harris	   For bug reports and moral support 
Rene Gollent	   For some great help
Les Ramer	   For some performance tips
Richard R.	   For more performance tips	
Ryu ChongJin	   For pointing out a subtle bug
"Sifun"		   For showing me how to disable the cursor
and many more... (don't feel bad if I forgot you, I just have a bad memory)!


Configuration
---------------------
You can set various tweaks with the configuration tool
Please select your card under "Card Model" for the optimum
configuration.  If you don't see your card, please select 
default, and let me know so I can add your card to the list!

VSync:
	Tells the card whether to wait for a vertical refresh before 
	swapping buffers.  May be faster in off position, but ugly 
	"tearing" may result.
Antialiasing:
	May result in smoother appearance, but will be much slower, 
	and only supported by some cards.
Texture clamp mode:
	Try selecting "alternate" if characters seem to have duplicate
	features (i.e., Link has three mouths).
Z-Buffer:
	Can be used to reduce "out of order polygon" problems.  For example,
	the pathways in Zelda may flash.  The default for your card should 
	work best, but you might want to play around.  G200 owners, please
	enable "32 bit zbuffer" in Matrox Display Properties for best results!
AlphaOps/ColorOps:
	Only for the advanced user.  Gray checkboxes mean "use defaults".  For
	those of you who are wondering, if the intro Mario has a black head, 
	unselect D3DTOP_ADD to get it looking correctly... and be sure to let me
	know what configuration you're using, so I can add that to the list!
	The other checkboxes may or may not fix other blending problems.
FPS Count:
	Makes a cute little FPS meter in the corner of the screen.  It actually
	decreases performance slightly, so only use it for comparison.
Process Priority:
	Really, this is only for UltraHLE, although it may work for other games.
	Set to High or Realtime to boost the priority of UltraHLE, hence increasing
	it's speed (and decreasing the sound skipping).
Buffering:
	Triple is fastest if you have an 8+ meg card, but it might not be compatible
	with some games.  Set to double if you're having problems.
Card model:
	Select your card from the list to load the optimum settings.  The database will
	be expanded in the future, especially with input from you guys!  If you would
	like to see an addition, and you know the best settings for that card, let me
	know and I'll add it to the list.
Logging:
	This setting should not matter much.  If your glide.log file is filling up
	to megabyte size with error messages, drop me a line with the messages you're
	getting so I can attempt to fix them.  In the meantime, you can disable the 
	logging so your game doesn't grind to a halt.
ATI Text Fix:
	Enable a workaround to make text visible on the ATI cards in Zelda.  May make 
	the game ugly in other parts, though.  I don't know of a way to truly fix it,
	since their driver is broken.
Auto Mipmap:
	Emulate mipmapping, for performance or graphic quality reasons.




Caveats
---------------------
Obviously, this is a work in progress.  
Many color/texture blending modes are not supported.  
You must have a hardware accelerator.
The wrapper will create a glide.log file in one of your directories.  It shouldn't get too
big unless you play for hours on end :-).
You'll quickly find out any other problems I forgot to mention :-).


Contacting me
---------------------
The best way is email, at spcutler@ucdavis.edu.  You may also visit my web page
at http://wwwcsif.cs.ucdavis.edu/~cutler (check out the programming section).  
You may also visit www.glideunderground.com for updates.


Version Log
---------------------
0.01   First versioned release
0.01a  Multi-resolution support
       Performance enhancements
       More color modes (Mario Kart fixes)
0.01b  Color mode fixes (Zelda fixes)
       Capability checking and logging
0.01c  (beta) Mario cart fixes
0.01d  (beta) Zelda text fixes for TNT and ATI cards
0.01e  Performance enhancements
       Official release of 0.01c-0.01d features
0.01f  Performance enhancements
       Zbuffer fixes, enhancements (water in Mario now correct)
0.01g  Zelda button text fixes
       Screenshots now work in UltraHLE
       NBA Live 98 almost works
0.01h  Mario Kart fixes
0.02   New configuration utility
0.02a  Fixed bug in config utility
0.02b  NFS2 SE now working again
       Performance enhancements
0.02c  More performance
       Broke NFS2, sorry :-(.
0.02d  NFS2 working again :-)
       Added FPS counter and priority setting to config util
       Color blending fixes
0.02e  Configurator additions
       Now correctly exits the window, so you may save games 
       to a file properly in UltraHLE
0.02f  Croc - Legend of the Gobbos working almost perfectly
       Fixed Z-buffer and color keying because of it (so other
       games may start working).
       Zelda text workaround on Rage cards
0.02g  Goldeneye bug fixed again
       Backend improvements
       Prformance enhancements
0.02h  Fixed palette support
       Compatibility improvements, Outlaws, Madtrax, NBA Live 98, and Croc
0.02i  Backend improvements
       Performance increases
0.02j  Frame buffer lock emulation (fixes Croc, among others)
       TNT Goldeneye fix
0.03   Removed the SDK!
       Lots of other bugfixes, I don't remember them all.
       The may be other problems, though, from converting to non-SDK code.
0.03a  Bugfixes galore!
0.04   Reworked LFB engine
       Reworked texture engine
       Paletted texture support
       More games working again (Unreal, etc)
       Fixed crashing bug
       Lots of other bug fixes!

License
---------------------
Copyright (C) 1998-1999 Scott Cutler

This library is free software; you can redistribute it and/or             
modify it under the terms of the GNU Library General Public               
License as published by the Free Software Foundation; either              
version 2 of the License, or (at your option) any later version.          
                                                                          
This library is distributed in the hope that it will be useful,           
but WITHOUT ANY WARRANTY; without even the implied warranty of            
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU         
Library General Public License for more details.                          
                                                                          
You should have received a copy of the GNU Library General Public
License along with this library; if not, write to the Free                
Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA 