************************************************************************************
***********************GoldenEye 007\Perfect Dark 1964 Bundle***********************
************************************************************************************

-----------------------------------How to Install-----------------------------------
� STEP 1: Extract the zip to your local disk. 1964 will not work correctly if you
  run it from within the zip.

� STEP 2: Run 1964. On first launch a dialog will appear asking which video plugin
  you wish to use. Jabo is an inaccurate but good for low end systems plugin, while
  GLideN64 is more accurate but requires a high end system to run at a constant 60fps.
  You can change your plugin later if you have slowdowns (see the below FAQ for plugin guide).

� STEP 3: Another dialog will appear asking for your ROM directory. Navigate the file
  explorer to your N64 ROM directory and click OK. If you don't have a N64 ROM folder
  just select the 1964 directory and place the ROMs inside there.

� STEP 4: Start GE\PD and press 4 to toggle the Mouse Injector on\off. If you want to
  adjust the sensitivity settings click the Plugins toolbar menu then click Input Settings.

--------------------------------------Controls--------------------------------------
PLUGIN HOTKEYS
4		- Toggle Mouse Injection\Lock Mouse Cursor

GAMEPLAY INPUT
WASD		- Movement
Enter		- Start
Q		- A button (Accept\Next Weapon)
E		- B button (Cancel\Use)
R		- Reload
Mouse 1		- Z button (Fire)
Mouse 2		- R button (Aim)
Mouse Wheel	- Next\Previous Weapon
CTRL		- Crouch
Mouse 2+W\S	- Sniper Zoom-In\Zoom-Out
Arrows		- Analog stick

EMULATOR HOTKEYS
F3		- Pause emulation (toggle)
F4		- Stop emulation
F5		- Quicksave
F7		- Quickload (may desync Mouse Injector)
F12		- Screenshot (saves to 1964 directory)
TAB		- Hide\Show Mouse Cursor
LSHIFT+1..9	- Select State (the Windows Asterisk sound will play when state has changed)
CTRL+V		- Change graphics settings (only in windowed mode)
CTRL+I		- Change input settings (only in windowed mode)
CTRL+C		- Cheats (only in windowed mode)
ALT+ENTER	- Fullscreen toggle
ALT+F4		- Closes 1964

-------------------------------------Known Bugs-------------------------------------
� The Mouse Injector only supports GoldenEye 007 (U) and Perfect Dark (U) (V1.1)

� Avoid pressing ALT+TAB while in fullscreen. Instead, exit fullscreen then pause 1964.

� Perfect Dark's Smart Slow Motion does not work at 60fps.

� Perfect Dark can sometimes start a level without music - open the pause menu to fix.

� Sometimes 1964 launches with long audio delay - pause (F3) and resume 1964 to fix this.

� 1964 can sometimes randomly lockup and not respond to hotkeys. To 'fix' this bug
  forcefully close 1964 (ALT+F4) and reopen 1964.

� For technical reasons the field of view\crosshair hack has to be applied before the
  game starts.

� If you are experiencing lag, lower overclock and change video plugin to Jabo 1.6.1.

-----------------------------------------FAQ----------------------------------------
Q:  How do I change plugins with 1964? And what are the differences for each plugin?
A:  Stop emulation and open the Plugins menu toolbar, then click the menu item "Change Plugins".

    Video plugin: You can choose between five plugins (ordered from quickest to slowest)
    Jabo 1.5.2\1.6.1: Fastest - many effects (lighting\water) and team colors are not emulated.
    GLideN64 2021: Slow, newest graphics plugin - accurate but requires a OpenGL 4 supported GPU.
    GLideN64 2020\2016: Included for people who have issues with latest GLideN64.
    Glide64: Slow, emulates almost everything - has issues with framebuffer\split-screen multiplayer.
    Shunyuan's SoftGraphic: Slowest, software RDP core from MAME. Used for testing custom levels.

    Audio plugin: You can choose between two versions of Azimer's HLE Audio plugin.
    Version 0.60\0.55.1: Quicker audio response but slightly stutters (your mileage may vary).
    Version 0.56: Slower audio response and does not stutter.

    Input plugin: Use Mouse Injector for keyboard and mouse. To use a USB controller instead
    read the next FAQ below for instructions.

    RSP plugin: RSP will be automatically set on\off for GoldenEye\Perfect Dark, leave this option alone.

    After the plugins have been chosen click OK.

    NOTE: If you would like to enable V-Sync and set anti-aliasing for Glide64, you
    will need to force it by creating a game profile for 1964 in your graphics control
    panel.

Q:  How do I use a joypad with 1964?
A:  Open the Plugins menu then click the menu item named "Change Plugins". Click the
    Input combobox and select N-Rage (any version). If N-Rage is not listed then you
    need to install DirectX (9.0c or later). Click OK and then open the Plugins menu
    and click Input Settings. Setup your joypad and once you are done click Save.

    If N-Rage does not detect your controller, change input plugin to DirectInput 1.20
    and try again.

Q:  My mouse isn't detected, how do I fix this?
A:  Try running 1964 in administrator mode.

Q:  How do I setup split-screen multiplayer with multiple keyboards\mice?
A:  If you have multiple mice\keyboards connected then you must set the input devices
    in the settings panel. Click the Plugins menu then click Input Settings, then set
    player 2\3\4 to WASD or another configuration. Next, select a player and click the
    "Detect Input Devices" button. Type\click to set the devices that you want to use
    per player. Click "OK" to save your changes.

Q:  How do I change the controls?
A:  Click the Plugins menu in 1964, then click Input Settings. The C-buttons are bound
    to WASD, and A and B buttons are bound to Q and E.

Q:  Why is WASD bound to the C-Buttons instead of the Analog stick?
A:  The C-Buttons are a better representation of WASD than the Analog stick.

Q:  How do I change the screen resolution for 1964?
A:  Just click the Plugins menu in 1964, then click Video Settings. The GUI for
    Glide64 and Jabo are easy enough to use so you shouldn't have any problems
    finding the fullscreen resolution settings. I do not recommend changing any
    other options.

Q:  Help, 1964 runs at 30fps and does not respond to hotkeys.
A:  Try changing the video plugin. If you still have issues try the following tips:

    Lower the overclock or set to stock
    Disable Max Kernel Frequency within User Options
    Force V-sync off in your graphics control panel
    Set compatibility mode to Windows 7
    Set core affinity to last core

Q:  I want to stream but it lags with OBS\XSplit, what can I do to make 1964 run better?
A:  Set the core affinity to 1964 to the last core, and set your recording software to
    use all cores except for the last one. For example if you have a 8 core CPU you'd
    set 1964 to use core 7, and OBS to use cores 0-6. 1964 is fine with one core.

Q:  The game is running beyond 60 frames per second, how do I fix this?
A:  Try turning on Video Speed Sync and disabling G-Sync\FreeSync.

Q:  How do I change the FOV calculation to compensate for 4:3 aspect ratio?
A:  Click the "Field of View:" display text in the settings panel and it will switch
    between 4:3 and 16:9 calculation.

Q:  How do I make GoldenEye 007\Perfect Dark more difficult with the Mouse Injector?
A:  Turn off auto-aim, sight on-screen and ammo on-screen. Increasing enemy reaction time
    to 100% is a must for GoldenEye 007.

Q:  I changed some settings and now Jabo plugin runs slow. How do I fix this?
A:  You may have enabled "Copy framebuffer to RDRAM" under advance settings in Jabo.
    To fix this untick "Copy framebuffer to RDRAM" and click OK.

Q:  Help, the Mouse Injector stutters a lot.
A:  Try changing the video plugin to Jabo or lower the overclock to stock.

Q:  The Mouse Injector responds sluggish to my mouse input. How do I make it quicker?
A:  Turn off V-Sync, Anti-Alias and Anisotropic Filtering for your video plugin.
    If this did not help, set your virus scanner to game mode or disable it altogether.

Q:  Why does Jabo insert a black border on the bottom of the screen for Perfect Dark?
A:  I suspect this is caused by Jabo's inaccurate emulation of the N64's Video Interface.
    Jabo does not accurately detect resolution changes so you'll get some instances
    of borders. You can manually override this in Jabo's Rom Settings tab (this is
    accessed by disabling the option "Hide Advance Settings") and set PD's emulated
    height to 220. While this will cause the game's introduction to be cropped, it
    will remove the bottom border for the rest of the game.

Q:  When I play GoldenEye there is 2 vertical lines on the edge of the screen, why?
A:  Old analog televisions never showed a 1:1 of the video input and would always
    overscan (crop) by some percent. GoldenEye was optimized to only draw within
    the "safe area" of a CRT television, as the outer edge of the screen would
    have been cropped from overscan. To fix this use GLideN64's overscan feature.

Q:  Why doesn't the Japanese\European version of GoldenEye work with the Mouse Injector?
A:  1964 and the Mouse Injector have been designed to only work with the USA versions
    of GoldenEye and Perfect Dark (v1.1). Other regional versions are not supported.

Q:  Could you explain what Set Max Kernel Frequency does in 1964?
A:  Kernel Frequency is an undocumented NT Windows Kernel function that changes the
    polling frequency of programs within a Windows environment. The Mouse Injector
    requires a high frequency to ensure smooth mouse input. The downside, it can drain
    laptop batteries and tax your system. The timer is set back to the default value
    when 1964 is closed. If you want to know more, research NtSetTimerResolution.

Q:  Why is NetPlay unavailable for 1964?
A:  Kaillera was removed due to 1964's non-deterministic timing emulation.

Q:  When I enter fullscreen, it zooms in to the bottom left corner of the game.
A:  Stop emulation and right click 1964, then click Properties. Go to the compatibility
    tab and click change high DPI settings -> override high DPI set to application.

Q:  I am using Glide64 and while playing PD my screen flickers, how do I stop this?
A:  You must change the Buffer swapping method for Glide64. Start Perfect Dark then
    open the Plugins menu, then click the menu item "Video Settings". In the new
    window tick the box "Show advance emulation options" and then click OK at the
    bottom. Reopen the config window for Glide64 and switch to the new tag titled
    "Emulation Settings". Change buffer swapping method to hybrid and click OK. A
    new window will appear asking if you want to save settings permanently, click Yes.
    If you still have issues try changing the buffer swapping method to Old.

Q:  I can't get any plugins to show up in the Change Plugins dialog window, how do I fix this?
A:  If you have a non ASCII filepath for 1964 it will not run properly. 1964 only supports
    ASCII character filepaths. I have tried to use relative filepaths but this breaks
    Windows 10 support. The best solution is to create a ASCII only filepath on your
    C:\ drive such as (C:\Games\Emulators\N64\) and place the 1964 directory there.
    If this does not help then check if 1964.exe has disk read\write permissions.

Q:  How do I launch 1964 from command line? I'd like to make a shortcut to run a ROM.
A:  1964 needs a active ROM directory already configured. The command line syntax
    for 1964 is the following:

    Syntax: 1964 [-f fullscreen_flag] [-v video_plugin_filename] [-a audio_plugin_filename] [-c controller_plugin_filename] [-g rom_name_inside_rom_directory] [-o overclock_factor_override]
    Example 1: 1964 -f -v Jabo_Direct3D8.dll -a AziAudio0.56WIP2.dll -c Mouse_Injector.dll -g Perfect_Dark.z64
    Example 2: 1964 -g goldeneye.z64
    Example 3: 1964 -f -o 12 -g perfectdarkromhack.n64

    1964 ignores spaces in arguments so rename your ROM if it contains space characters.
    The plugin arguments are optional & if not provided will use settings from 1964.cfg.

--------------------------------------Changelog-------------------------------------
Carnivorous' Fixes - 2023/07/03
� Bundle - Added 2020 GLideN64 WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated cheats
� Bundle - Updated GLideN64 to WIP build
� Bundle - Added fork of Azimer 0.55.1 (less stuttering)
� Bundle - Changed default settings for Azimer 0.60 (less stuttering)
� Bundle - Added new cheats for GoldenEye 007\Perfect Dark
� Bundle - New texture pack for Perfect Dark by Trov (thank you)
� Bundle - Added legacy GLideN64 V2 build
� Bundle - Updated readme FAQ
� Bundle - Rewrote install guide and FAQ
� Bundle - Updated readme FAQ
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Updated GLideN64 to WIP build
� Bundle - Fixed GLideN64 mipmaps
� Bundle - Updated GLideN64 to WIP build
� Bundle - New GLideN64 texture pack for GoldenEye (HUD only)
� Bundle - Updated GLideN64 to WIP build
� Bundle - Added DirectInput plugin
� Bundle - Updated readme FAQ and install guide
� Bundle - Updated GLideN64 (Public Release 4.0)
� Bundle - Updated GLideN64 to WIP build
� Bundle - Recompiled RSP.dll
� Bundle - Added beta crosshair to texture pack
� Bundle - Updated GLideN64 to WIP build (split-screen supported)
� Bundle - Updated readme FAQ
� Bundle - Updated 1964.ini to use correct defaults for all ROMs
� Bundle - Updated readme FAQ (thanks to Graslu00)
� Bundle - Added 30fps cheat for GE\GF
� Bundle - Replaced No Audio 1964.dll with No Audio.dll (more stable)
� Bundle - Updated readme FAQ (thanks to DuskyLW and Pheonarx)
� Bundle - Updated N-Rage plugin to 2.3d
� Bundle - Added counter factor settings to 1964.ini for GE\PD
� Bundle - Updated Glide64.ini to use new buffer swapping for Perfect Dark\GoldenEye: X
� Bundle - Inserted Goldfinger 64 CRC to 1964.ini\Project64.rdb\Glide64.ini
� Bundle - Cleaned up readme
� Bundle - New Glide64 texture pack for GoldenEye (HUD only)
� Bundle - Removed standalone Perfect Dark speed-hack (now included in 1964)
� Bundle - Unpacked UPX compressed dlls msvcp60d.dll and msvcrtd.dll
� Bundle - Replaced ASPack'd zlib.dll with unmodified zlib.dll
� Bundle - Replaced saves with more complete saves
� Bundle - Updated readme guide and FAQ (thanks to Graslu00 and Oxygen)
� Bundle - Fixed typo in readme (thanks to Rekrul)
� Bundle - Updated GLideN64 (Public Release 2.0)
� Bundle - Inserted GoldenEye: X 5e CRC to 1964.ini\Project64.rdb
� Bundle - Inserted GoldenEye: X 5d CRC to 1964.ini\Project64.rdb
� Bundle - Removed GE-MP (unfinished and source of false positive antivirus detection)
� 1964 - Backported 1964 1.1 message pump fixes
� 1964 - Prevent Windows DPI scaling
� 1964 - Rewrote PD speed-hack (thanks to Ryan Dwyer)
� 1964 - Added overwrite overclock factor argument to CLI
� 1964 - Backported 1964 1.1 video plugin DLL initialization fix
� 1964 - Replaced various strcmp calls for handling internal ROM name
� 1964 - GE - Added disable head roll hack
� 1964 - GE - Fix firing rate of watch laser at 60fps
� 1964 - Set default GLideN64 option to stable 2020 build
� 1964 - GE - Fixed drone guns firing rate at 60fps
� 1964 - Fixed Natalya\camping guards breaking at 60fps
� 1964 - Adjusted window position saving
� 1964 - Improved timing stability
� 1964 - Added simplified change plugin dialog
� 1964 - Updated hotkey info dialog on first launch
� 1964 - Repacked INI_ENTRY_STRUCT
� 1964 - Increased ROM ini entries to 50000
� 1964 - Improved PD overclock
� 1964 - Always pause when configuring plugins
� 1964 - Replace Hide Cursor on Launch with Auto Hide Cursor option
� 1964 - Added hotkey info dialog on first launch
� 1964 - Removed Kaillera support
� 1964 - Rewrote PD speed-hack (thanks to Ryan Dwyer)
� 1964 - Added option to auto hide cursor on launch
� 1964 - Will ask user which video plugin to use on first launch
� 1964 - Fixed borderless fullscreen bug on ROM close
� 1964 - Added borderless fullscreen mode
� 1964 - Always disable autoload cheats on start up
� 1964 - Fixed Memory Pak corruption for players 2\3\4
� 1964 - Added 60fps firing rate fix to GE
� 1964 - Added region checks for GE\PD hacks
� 1964 - Adjusted filename for loading RSP.dll
� 1964 - Only update Project64.rdb if using Jabo
� 1964 - Status bar shows correct CF on launch
� 1964 - Default rdram\counter factor set to - 1 & 8mb
� 1964 - Opening cheats will now restore mouse cursor
� 1964 - Fixed show\hide cursor bug when returning from dialog window
� 1964 - Cheat settings will load from 1964.cfg
� 1964 - Combat boost now works at 60fps
� 1964 - No longer reset counter factor settings for GE\PD
� 1964 - Tweaked the default window size
� 1964 - Improved timing stability for GE\PD
� 1964 - Fixed GoldenEye TLB gamehack that caused issues with 24MB ROM hacks
� 1964 - Removed maximize button
� 1964 - Added option to increase PD speed-hack frequency
� 1964 - Reduced PD speed-hack inject rate (less aggressive)
� 1964 - Fixed bug that caused game to soft lock when unpaused
� 1964 - Fixed Memory Pak corruption on first write
� 1964 - Improved GE\PD ROM detection for loading default settings (supports Perfect Dark +)
� 1964 - Added PD speed-hack from Mouse Injector (more stable)
� 1964 - Will ask user for ROM folder on first launch
� 1964 - Profiling stats disabled by default
� 1964 - Changing states will display the new slot # in the Status Bar
� 1964 - Reverted relative filepath for saves\plugins as it caused issues with Windows 10
� 1964 - Removed CTRL+R hotkey for RSP plugin settings
� 1964 - Fixed bug with ROM properties window not displaying the correct defaults for GE\PD
� 1964 - Lock counter factor to 1 while Overclocking
� 1964 - Default counter factor set to 2
� 1964 - Extended overclock to 18 times (requires powerful CPU)
� 1964 - Removed overclock profiles (combined all in one exe)
� 1964 - Integrated overclocking into menu
� 1964 - Fixed save issue with uncommon characters in filepath
� 1964 - Removed registry functionality (uses 1964.cfg instead)
� 1964 - New icon provided by deuxsonic
� 1964 - Maximum Kernel Frequency on by default
� 1964 - New option - Set Maximum Kernel Frequency (thanks to deuxsonic)
� 1964 - New option - Disable Status Bar
� 1964 - Cursor is unhidden when opening plugin configuration windows
� 1964 - Backported 1964 1.1 cheat engine (better compatibility)
� 1964 - TAB now hides status bar (thanks to deuxsonic)
� 1964 - On first load, set input plugin to Mouse Injector in registry
� 1964 - Unpause only when entering fullscreen
� 1964 - Fixed cursor hiding while changing plugin settings
� 1964 - Fixed show\hide cursor bug (TAB now toggles cursor)
� 1964 - Changed filenames - caused emu detect issues in W10 (thanks to Stunning Cactus)
� 1964 - Auto enable\disable RSP emulation for GoldenEye 007\Perfect Dark (ROM name detection)
� 1964 - Adds ROM CRC to Project64.rdb when running new ROM (for Jabo compatibility)
� 1964 - Default plugins set to Jabo - Mouse Injector - Azimer
� 1964 - Romlist shows filename by default
� 1964 - Set Perfect Dark\GoldenEye: X to EEPROM 16KB (ROM name detection)
� 1964 - Two overclock profiles - six\nine times
� 1964 - Compiled non-overclocked 1964 version - for slow cpus\novelty
� Mouse Injector - Added stick buffering for slayer fly-by-wire input
� Mouse Injector - Fix null check for wide character path resolving
� Mouse Injector - PD - Rebind slayer's fly-by-wire input handling
� Mouse Injector - PD - Rewrote camspy handling
� Mouse Injector - Hide device combo boxes if only a single mouse\keyboard is available
� Mouse Injector - Fix defined error for device\player\button structs
� Mouse Injector - Version 2.3 Released
� Mouse Injector - Added new option to bypass ViewModel FOV position tweak
� Mouse Injector - GE - Fixed bug with new reload button when holding dual weapons
� Mouse Injector - GE - Adjust crosshair scale with ratio override
� Mouse Injector - Added new separate reload button for GE\PD
� Mouse Injector - Updated Copyright
� Mouse Injector - GE - Fixed menu crosshair moving upwards on down arrow
� Mouse Injector - PD - Fixed blur carrying over after respawning
� Mouse Injector - Use -128 for analog stick min value
� Mouse Injector - Force Horizon Scanner to not use cursor aiming
� Mouse Injector - PD - Rewrote Hoverbike support (thanks to Ryan Dwyer)
� Mouse Injector - Move GAME_Quit() call to end of DEV_InjectThread()
� Mouse Injector - Improved sanity checks and optimized inject()
� Mouse Injector - Adjusted UI
� Mouse Injector - Version 2.2 Released
� Mouse Injector - PD - Added new kneel button
� Mouse Injector - Increased cursor lock frequency
� Mouse Injector - Adjusted UI
� Mouse Injector - Always force 1.2 control style and upright pitch
� Mouse Injector - Version 2.1 Released
� Mouse Injector - Improved GE show crosshair hack
� Mouse Injector - Fixed if statement failing on 21:9 ratio
� Mouse Injector - Fix gun x rotation scale issue with custom ratios
� Mouse Injector - Updated speedrun build info message
� Mouse Injector - Optimized GUI message pump
� Mouse Injector - Removed FOV\ratio options for speedrun build
� Mouse Injector - Fixed while loop bug on ROM start
� Mouse Injector - Added custom widescreen ratio support
� Mouse Injector - PD - Added FOV override zoom speed adjustment
� Mouse Injector - PD - Made radial menu appear faster
� Mouse Injector - Version 2.0 Released
� Mouse Injector - Adjusted Discord Rich Presence text and descriptions
� Mouse Injector - Adjusted UI
� Mouse Injector - Rewrote BONDDATA scanning
� Mouse Injector - Lowered FOV range for speedrun build
� Mouse Injector - Adjust weapon position for override FOV
� Mouse Injector - Compensate for override FOV while in aim mode
� Mouse Injector - Limit SetCursorPos execution
� Mouse Injector - Updated Copyright
� Mouse Injector - Sanity check pickup threshold before overwriting
� Mouse Injector - Created speedrun build (removes FOV advantage and pickup threshold adjustment)
� Mouse Injector - Version 1.9 Released
� Mouse Injector - Lock crosshair X axis when driving the tank while tank equipped as weapon
� Mouse Injector - Override camera Y axis pickup threshold (from -45 to -60)
� Mouse Injector - Added enum type for mouse\keyboard
� Mouse Injector - Enable revert after clicking detect input button
� Mouse Injector - Flush input when starting injection thread
� Mouse Injector - Replaced pthread_create with CreateThread
� Mouse Injector - Doubled BONDDATA scanning time
� Mouse Injector - Use beta crosshair when show crosshair is enabled
� Mouse Injector - Fixed EMU_ReadShort()
� Mouse Injector - Removed offset parameter from memory.h
� Mouse Injector - Version 1.8 Released
� Mouse Injector - Cleaned up ini loading and device function
� Mouse Injector - Safely close ManyMouse and Discord Rich Presence on shutdown
� Mouse Injector - Added option to compile without discord rich presence in makefile
� Mouse Injector - PD - Compute recoil rotation
� Mouse Injector - Increased FOV sanity check range (for ROM hacks)
� Mouse Injector - Added Discord Rich Presence support
� Mouse Injector - Version 1.7 Released
� Mouse Injector - Reduced mouse acceleration
� Mouse Injector - PD - Cursor aiming now supported
� Mouse Injector - Emulate centering code when cursor aiming is disabled
� Mouse Injector - Removed overclock requirement for cursor aiming
� Mouse Injector - Recalibrated aiming table for GE
� Mouse Injector - Added GE hack for jitter free aiming mode
� Mouse Injector - Removed unused define in goldeneye.c
� Mouse Injector - Analog stick value set to 127 from 120
� Mouse Injector - Fixed FOV hack not replacing init value for GE
� Mouse Injector - Version 1.6 Released
� Mouse Injector - Restored autolock option (thanks to deuxsonic)
� Mouse Injector - Fixed sanity check for FOV ini load
� Mouse Injector - Emulate logic for camspy\slayer
� Mouse Injector - Added intro skip button combo for GE\PD (FIRE+AIM)
� Mouse Injector - Added camspy\slayer compatibility for PD
� Mouse Injector - Fixed non-zooming weapons reverting to default FOV
� Mouse Injector - Replaced autolock option with unlock on window loss
� Mouse Injector - Added geshowcrosshair to INI_Reset()
� Mouse Injector - Now removes GE autostand code
� Mouse Injector - Added Show Crosshair for GE option
� Mouse Injector - Version 1.5 Released
� Mouse Injector - Added Copyright notice for ManyMouse library
� Mouse Injector - Fixed edge case where ManyMouse would fail to initialize (thanks to Marthur)
� Mouse Injector - Inlined memory functions used by goldeneye.c\perfectdark.c
� Mouse Injector - Refactored codebase to use headers more effectively
� Mouse Injector - If Mouse Sensitivity is set to 0%, show None instead
� Mouse Injector - Allow Mouse Sensitivity to be set to 0%
� Mouse Injector - Removed PD speed-hack
� Mouse Injector - Rewrote Hoverbike pointer scanning (less false positives)
� Mouse Injector - Increased FOV ViewModel Warning (only displays above 75*)
� Mouse Injector - Uses wide character filepath to access ini file
� Mouse Injector - Mouse Acceleration is applied for GoldenEye cursor aiming
� Mouse Injector - Fixed bug where bike pointer was incorrectly detected
� Mouse Injector - Use double slash argument for fopen
� Mouse Injector - Replaced atol with atoi
� Mouse Injector - Version 1.4 Released
� Mouse Injector - GE - While in menus, Aim button is binded to B button
� Mouse Injector - New option - Mouse Acceleration
� Mouse Injector - Fixed GE ROM hack crouch bug
� Mouse Injector - Fixed keyboard race condition - input would not detect keydown every poll
� Mouse Injector - FOV compensates for horizontal aspect ratio
� Mouse Injector - UI Improvements
� Mouse Injector - Version 1.3 Released
� Mouse Injector - Fixed clear bug when profile was empty
� Mouse Injector - Accept all device input if one player is the only active profile
� Mouse Injector - Uncheck Cursor Aiming and speed-hack for non-overclocked 1964 (to avoid confusion)
� Mouse Injector - PD - Improved speed-hack
� Mouse Injector - New option - Field of View slider (thanks to SubDrag)
� Mouse Injector - New option - Perfect Dark speed-hack toggle
� Mouse Injector - Created MinGW makefile
� Mouse Injector - Converted Mouse Injector to ISO C11
� Mouse Injector - Version 1.2 Released
� Mouse Injector - Increased sensitivity range to 500%
� Mouse Injector - Replaced windows injection with direct injection
� Mouse Injector - Removed ReadProcessMemory\WriteProcessMemory functions
� Mouse Injector - Fixed secondary button load bug
� Mouse Injector - Version 1.1 Released
� Mouse Injector - Fixed bug where secondary buttons would not apply
� Mouse Injector - Fixed revert button bug (reverted all players instead of current player)
� Mouse Injector - New option - Autolock Mouse on Window Focus
� Mouse Injector - Fixed edge case where foreground window is incorrectly set upon launching ROM
� Mouse Injector - Cleaned up code and fixed comment typos
� Mouse Injector - Optimized input and injection (bypass disabled players)
� Mouse Injector - PD - Disable speed-hack if slo-mo cheat is detected (ignored for PD ROM hacks)
� Mouse Injector - Removed Project64 support (unstable and incompatible with ManyMouse)
� Mouse Injector - Fixed edge case crash when initializing plugin
� Mouse Injector - Created icon for standalone speed-hack
� Mouse Injector - Created standalone Perfect Dark speed-hack for N-Rage plugin
� Mouse Injector - Informative message boxes now have icons
� Mouse Injector - PD - Fixed rare case where radial menu direction would become stuck
� Mouse Injector - PD - Clicking in radial menu now resets back to center
� Mouse Injector - PD - Fixed bug where radial menu direction would apply after match ended
� Mouse Injector - Increased mouse wheel tickrate
� Mouse Injector - Fixed crash when opened config window after closing ROM
� Mouse Injector - Supports 4 players
� Mouse Injector - Converted to plugin
� Mouse Injector - Mouse locks correctly on multi-screen setups
� Mouse Injector - Now reads from driver (thanks to ManyMouse by rcg)
� Mouse Injector - Replaced strcmp with strcasecm - possible source of emu detect issues
� Mouse Injector - New option - Radial menu mouse control for Perfect Dark
� Mouse Injector - New option - Toggle Crouch
� Mouse Injector - PD - Disable speed-hack if player is using combat boost or match is slow motion
� Mouse Injector - Capped emulator search rate
� Mouse Injector - Capped injection rate for Perfect Dark speed-hack (was unstable)
� Mouse Injector - Changed description for Aim Mode to Cursor Aiming
� Mouse Injector - Crosshair Movement set to 50% by default
Extra - 2014/08/06
� Mouse Injector - Added ability to change the default crouch key (see FAQ for how-to)
� Mouse Injector - Added ability to disable aiming mode for GE (1964 60fps build only)
� Mouse Injector - Lock Settings now renamed to Hide/Show Settings
� Mouse Injector - Reduced Crosshair Movement default by 50%
� Special thanks to /vr/ for suggestions and input
Final - 2014/03/11
� Updated 1964.ini and Project64.rdb to support latest version of GoldenEye X
� Mouse Injector - Mouse Cursor now locks to where the mouse cursor is located upon enabling the injector
� Mouse Injector - Forces Perfect Dark to always run at 60 frames per second (1964 60fps build only)
� Mouse Injector - Replicated GoldenEye 007 aiming mode design (1964 60fps build only)
� Mouse Injector - New crouching system for GoldenEye 007 (fixed stuttering)
� Mouse Injector - Mouse Sensitivity precision set to 5% intervals
� Mouse Injector - Debug option removed from release build
� Mouse Injector - Added Lock Settings hotkey (CTRL+0)
� Mouse Injector - Tickrate option removed
� Added xinput1_3.dll (for N-Rage)
� Added DarkMan's DInput plugin to bundle
� Added more questions and answers to FAQ in readme
� Mouse Injector and GE-MP are now licensed under BSD
v1.5d - 2013/04/22
� Mouse Injector supports PD hoverbikes (works 99% of the time)
� Fixed GE-MP interface bug (countdown no longer switchable in client mode)
� Updated 1964.ini, Project64.rdb and Glide64.ini to support latest version of GoldenEye X
� Added Shunyuan's SoftGraphic plugin (based on accurate RDP core from MESS project)
� Mouse Injector limits crosshair moving beyond the default range for Y axis
� New profiles in GoldenEye 007 will use controller layout 1.2 by default
� Removed save option from Mouse Injector (autosaves on exit)
� Improved interface for GE-MP and Mouse Injector
� Added Mouse Wheel weapon selection macro
� Rewrote install guide and improved FAQ
� Cleaned up Mouse Injector code
� 1964 - Removed Reset button
� 1964 - Pressing TAB will hide Mouse Cursor
� 1964 - State Slot can only be changed using Left Shift + 1..9
v1.5c - 2013/01/31
� Mouse Injector uses GE-MP's memory scanning design
� Mouse Injector no longer supports PD hoverbikes
� Mouse Injector supports GE/PD ROM hacks
� GE-MP and Mouse Injector now support Project64 1.6 (official build)
� 1964 - Saves use country name instead of ROM CRC
� 1964 - Video Speed Sync is reset upon start up
� 1964 - Counter factor default is 1
� 1964 - RDRAM default size is 8MB
v1.5b - 2012/11/19
� Added Mupen64Plus 1.99.5 support for GE-MP and Mouse Injector, as requested by user buvk
� Rewrote GE-MP and Mouse Injector's ROM detection
� Improved GE-MP round quit code
� Fixed many bugs and cleaned up code for Mouse Injector and GE-MP
� Mouse Injector no longer injects mouse if multiplayer menu is open or when round has finished
v1.5a - 2012/09/23
� Updated Mouse Injector to support latest version of GoldenEye X
� Updated 1964.ini, Project64.rdb and Glide64.ini to support latest version of GoldenEye X
� Updated N-Rage plugin to version 2.3c (latest)
� GE-MP - Version 0.5 released
� GE-MP - Improved hurt code
� GE-MP - Fixed glitch when player 2 exits menu
v1.5 - 2012/04/19
� GE-MP - Tickrate is quicker to change
� GE-MP - Reverted netcode changes (every packet is confirmed)
� GE-MP - Inventory is synced
� GE-MP - MWTGG and flag tag are now supported
� GE-MP - Weapon drops now synced (but not positions)
� GE-MP - Added spawn with PP7 feature
� GE-MP - Fixed random round exits
� GE-MP - Now supports custom weapon sets (and up to 10 weapons synced)
� GE-MP - Added tickrate rating system
� GE-MP - Fixed round quitting system for client (still crashes but not so frequently)
� GE-MP - Fixed connection display issues
� GE-MP - Server quits to menu when client has disconnected
� GE-MP - Added setup guide
v1.49 - 2012/04/17
� GE-MP - Only inject character data from other player
� GE-MP - Fixed round quitting system for client (still crashes, but not as common)
� GE-MP - Replaced tickrate range (5ms to 80ms)
� GE-MP - Now no longer confirms packet (checks for menu packets)
v1.48 - 2012/04/16
� GE-MP - Improved map detection
� GE-MP - Fixed LTK mode (now makes players have 0 hp)
� GE-MP - Freeze menu for server until client connects
� GE-MP - Removed ultra low ranges for tickrate (too many injections = crashed emulator)
� GE-MP - All characters unlocked by default
� GE-MP - MWTGG and flag tag still broken (working on inventory sync)
� Cleaned up Mouse Injector code comments
� Renamed readme to BUNDLE_README.txt
v1.47 - 2012/04/09
� Mouse Injector now pauses before closing automatically when emulator is not detected
� GE-MP - LTK mode now implemented
� GE-MP - Removed debug hotkey (left in by accident)
� Touched up readme, and renamed to "PLEASE_DON'T_READ_ME.txt"
v1.46 - 2012/04/06
� GE-MP - Viewing start menu in-game will not make other player open up start menu
� GE-MP - Optimized time sync message
� GE-MP and Mouse Injector can use both +/- keys on keyboard
v1.45 - 2012/04/01
� Renamed Multiplayer to GE-MP
� GE-MP - Fixed some issues with deaths not syncing
� GE-MP - Fixed some glitches when returning to menu
� GE-MP - Fixed glitch for score based time limits matches
� GE-MP - Added larger tickrate range
� Mouse Injector and GE-MP have new icons
v1.44 - 2012/03/30
� Multiplayer - No longer crashes players when returning to menu
� Multiplayer - Now streams input to emulator via multithreading
� Multiplayer - No longer has desynced gun models
� Multiplayer - Added no shields feature
� Multiplayer - Tickrate now controlled by server
v1.43 - 2012/03/29
� Released beta multiplayer client/server for GoldenEye 007 (source code is ugly)
� Fixed searching issue for Mouse Injector
v1.42 - 2012/03/19
� Cleaned up code errors (don't copy and paste code)
v1.41 - 2012/03/16
� Converted Mouse Injector to GNU99 (now compiled with MinGW)
� Changed version number of bundle
v1.4 - 2012/03/12
� Fixed some logic issues with the interface coding with Mouse Injector
v1.39 - 2012/03/07
� Fixed some logic bugs with Mouse Injector
� Fixed up some outdated notes in readme
v1.38 - 2012/02/29
� Rewrote Mouse Injector, with improved hoverbike scanning and fixed bugs
� Updated N-Rage input plugin to 2.3
� Included broken proof of concept multiplayer prototype
v1.37 - 2012/01/16
� Added Mupen64++ Beta 0.1.3.12 support, as requested by user buvk
v1.36 - 2012/01/11
� Replaced PistolGrip's build with stolen's 0.8.5 build
� Updated Mouse Injector to support stolen's 0.8.5 build
� Added overclocking mods to timer.c (thank you death--droid and RetroRalph)
� Fixed 1964 crash when pressing CTRL+A/CTRL+D/CTRL+S
� Replaced ugly 1964 icon with a new ugly icon
v1.35 - 2011/12/31
� Cleaned up code for Mouse Injector
� Restarted development on multiplayer client and server for GoldenEye 007
v1.34 - 2011/12/30
� Updated Glide64 to final version
� Fixed saving/loading logic bug related with currenteditingsway variable
v1.33 - 2011/12/27
� Fixed comment errors
� Fixed saving/loading logic bug related with currenteditingsensitivity variable
� Mouse Injector stops injecting when GoldenEye is paused
v1.32 - 2011/12/23
� Project64 support removed from Mouse Injector due to dynamic addresses (not static)
� Cleaned up some code and comments
v1.31 - 2011/12/16
� Mouse Injector now supports the popular emulator Project64 v1.6
� Mouse Injector source code cleaned up and in K&R style of C (thanks AStyle)
� Mouse Injector addresses are now emulator neutral
v1.3 - 2011/12/03
� Updated Glide64 to latest version (revision 266)
� Updated Glide64.ini and set hotkey to 0
� Released source code to Mouse Injector under GPL v2
� Included 1964 0.8.5 source code to bundle
v1.29 - 2011/11/09
� Improved Mouse Injector interface
� Increased editable range for gun sway (you're now able to disable gun sway)
v1.28 - 2011/11/03
� Removed poor quality texture pack from bundle
� Mouse Injector.exe not compressed with UPX (can give false virus warnings)
� Updated Glide64 to latest version (revision 254)
v1.27 - 2011/10/14
� Added latest version of N-Rage input plugin
� Updated Jabo DX8 video plugin to latest version (skies are rendered)
� Mouse Injector gun sway sensitivity now editable
� Multiplayer client/server abandoned (see FAQ)
� Dumped more cloned interpret display names for current textures
v1.26 - 2011/10/05
� Mouse Injector save design is updated (less buggy)
� Improved colors of Archives wall textures
� Cleaned up code
� Added weapon movement support to Mouse Injector
� Removed changelog.txt file and readded changelog into readme
� Dumped more cloned interpret display names for current textures
v1.25 - 2011/09/21
� Fixed bug where limit rate would be changed when changing sensitivity
� Added FAQ in readme
� Added save settings feature
� Fixed Perfect Dark multiplayer camera sweep from being movable
� Dumped more cloned interpret display names for current textures
� Created Archives wall textures
v1.24 - 2011/09/14
� Perfect Dark hoverbike is now mouse supported
� GoldenEye 007 tank is now mouse supported
� Fixed GoldenEye 007 map camera sweep from being movable
� GoldenEye 007 mouse support is 100% complete
� Dumped more cloned interpret display names for current textures
� Suspended development of plugin version
� Started development on multiplayer client and server for GoldenEye 007
v1.23 - 2011/09/09
� Fixed double injection bug
v1.22 - 2011/09/08
� Added GoldenEye X support to Mouse Injector
� Rewritten Mouse Injector (better injection design, less bugs)
� Improved guide
� Dumped more cloned interpret display names for current textures
v1.21 - 2011/09/01
� Created changelog.txt file
� Added reverse pitch option to Mouse Injector
� Improved readme
v1.2 - 2011/08/31
� Added console title
� Improved guide
� Dumped more cloned interpret display names for current textures
� F9 now supports Perfect Dark
� Updated Glide64 to latest version (quicker cloak effect rendering)
v1.19 - 2011/08/30
� Improved readme
� Dumped more cloned interpret display names for current textures
� Mouse locks at centre of screen instead of 600x600
v1.18 - 2011/08/29
� Added icon to Mouse Injector
� Dumped more cloned interpret display names for current textures
� Improved readme
v1.17 - 2011/08/15
� Improved readme
� Dumped more cloned interpret display names for current textures
� Started work on plugin edition of the Mouse Injector
� Fixed emulator issue with Perfect Dark playing at 120 frames per second
v1.16 - 2011/08/07
� Fixed interface bug
� Dumped more cloned interpret display names for current textures
v1.15 - 2011/08/04
� Improved interface
� Disable crouch when mouse is disabled
� Added debug mode
� Fixed GoldenEye 007 crosshair moving without any mouse movement
v1.14 - 2011/08/01
� Added XP support
� Dumped more cloned interpret display names for current textures
v1.13 - 2011/07/29
� Fixed Perfect Dark's Group 3 not found error
� Remade GoldenEye 007 sky texture (GoldenEye 007#22D9AAA5#3#1_all)
v1.12 - 2011/07/28
� Removed unfinished heads from texture pack
� Fixed some bugs with crouching (still needs a rewrite)
� Improved build date information
v1.11 - 2011/07/27
� Mouse Injector GoldenEye 007 menu sensitivity decreased
� Dumped more cloned interpret display names for current textures
� Inserted build version and date into interface
v1.1 - 2011/07/26
� Many bug fixes, including better crouching method for both games
� Included WIP texture pack
v1.0 - 2011/07/23
� First release with new Mouse Injector, rewritten in C++ by stolen
v0.9 - 2011/06/27
� Created GoldenEye 007 bundle with PistolGrip's 1964 build and Mouse Injector by uncle bone
v0.1 - 2011/06/27
� Nearly captured all the cloned interpret display names for current textures
v0.03 - 2011/01/24
� Dumped more interpret display names for textures
v0.02 - 2010/10/27
� Dumped more interpret display names for textures
v0.01 - 2010/10/25
� Changed version name system
� Fixed a few textures that were bug-ish with Glide64
v0.0.2 - 2010/10/22
� Fixed the sky (GoldenEye 007#22D9AAA5#3#1_all)
v0.0.1 - 2010/10/15
� All textures are placeholders that will be replaced with better, non-stolen textures
  in the future